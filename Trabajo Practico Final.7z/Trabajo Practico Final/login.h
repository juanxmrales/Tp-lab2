#ifndef LOGIN_H_INCLUDED
#define LOGIN_H_INCLUDED
#define L 80





void login();





#endif // LOGIN_H_INCLUDED
