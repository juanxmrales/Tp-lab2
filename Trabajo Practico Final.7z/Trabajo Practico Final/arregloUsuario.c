#include "arregloUsuario.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


stUsuario cargarUsuario (int cant)
{
    stUsuario usuario;
    usuario.idUsuario = cant+1;
    printf("Ingrese nombre de usuario:");
    fflush(stdin);
    gets(usuario.nombreUsuario);
    printf("Ingrese contrasenia:");
    fflush(stdin);
    gets(usuario.contrasenia);
    printf("Ingrese anio nacimiento:");
    fflush(stdin);
    scanf("%d",usuario.anioNacimiento);
    printf("Ingrese genero:   F/M ");
    fflush(stdin);
    scanf("%c",&usuario.genero);
    printf("Ingrese pais:");
    fflush(stdin);
    gets(usuario.pais);
    printf("Ingrese correo electronico:");
    fflush(stdin);
    gets(usuario.correoElectronico);
    usuario.eliminado = 0;
    usuario.aprobado = 0;
    usuario.tipoUsuario = 0;

    return usuario;
}


int cargarArreglo(stCelda A[],int cant)
{
    char control='s';
    stUsuario user;
    int validos=0;

    do
    {
        user = cargarUsuario(cant);
        printf("Desea continuar?\n");
        fflush(stdin);
        scanf("%c",&control);
        validos ++;
        fflush(stdin);

    }while (control=='s' && validos<cant);


    return validos;
}

 void mostrarArreglo(stUsuario A[],int cant)
 {
     for (int i=0;i<cant;i++)
     {
         printf("ID Usuario: %d\n",A[i].idUsuario);
         printf("Nombre: %d\n",A[i].nombreUsuario);
         printf("contrasenia: %d\n",A[i].contrasenia);
         printf("Anio Nacimiento: %d\n",A[i].anioNacimiento);
         printf("Genero: %d\n",A[i].genero);
         printf("Pais: %d\n",A[i].pais);
         printf("Correo Electronico: %d\n",A[i].correoElectronico);
         printf("Dado de Baja: %d  0 no - 1 si\n",A[i].eliminado);
         printf("Aprobado: %d  0 aprobado - 1 pendiente\n",A[i].aprobado);
         printf("Tipo de Usuario: %d 0 usuario - 1 admin\n",A[i].tipoUsuario);
     }
 }


/*int idUsuario;
   char nombreUsuario[30];
   char contrasenia[20];
   int anioNacimiento;
   char genero;
   char pais[20];
   char correoElectronico[50];
   int eliminado; // indica 1 o 0 si el cliente fue eliminado
   int aprobado;//indique 1 o 0 si el cliente esta aprobado por el admin
   int tipoUsuario;//1 admin
*/
