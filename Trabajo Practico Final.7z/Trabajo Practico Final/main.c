#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "login.h"
#include "arregloUsuario.h"

int main()
{
    ///login();

    stCelda arreglo [30];
    int cant=0;
    cant=cargarArreglo(arreglo, 30);
    mostrarArreglo(arreglo ,cant);
    printf("control");

    return 0;
}





