#ifndef ARREGLOUSUARIO_H_INCLUDED
#define ARREGLOUSUARIO_H_INCLUDED


typedef struct
{
    int idUsuario;
    char nombreUsuario[30];
    char contrasenia[20];
    int anioNacimiento;
    char genero;
    char pais[20];
    char correoElectronico[50];
    int eliminado; // indica 1 o 0 si el cliente fue eliminado
    int aprobado;//indique 1 o 0 si el cliente esta aprobado por el admin
    int tipoUsuario;//1 admin
} stUsuario;


typedef struct
{
    stUsuario usr;
    //nodoListaCancion * listaCanciones;
} stCelda;



#endif // ARREGLOUSUARIO_H_INCLUDED
